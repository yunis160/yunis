
document.querySelectorAll(".star").forEach(star => {
  star.addEventListener("click", function() {
    const rating = this.getAttribute("data-value");
    document.querySelectorAll(".star").forEach(s => {
      s.classList.remove("active");
      if (s.getAttribute("data-value") <= rating) {
        s.classList.add("active");
      }
    });
  });
});

document.getElementById("orderForm").addEventListener("submit", function(e) {
  e.preventDefault();
  document.getElementById("successMessage").style.display = "block";
});
